import UIKit

import UIKit

class ButtonWithShadow: UIButton {

    // This method is called when the button is drawn.
    override func draw(_ rect: CGRect) {
        // Calls the method to update layer properties.
        updateLayerProperties()
    }

    // Function to update the layer properties, adding the shadow effect.
    func updateLayerProperties() {
        // Set the shadow color with a black color that has 25% opacity.
        self.layer.shadowColor = UIColor(red: 0, green: 0, blue: 0, alpha: 0.25).cgColor
        // Set the shadow offset to (0, 3), which means a shadow will be cast to the bottom.
        self.layer.shadowOffset = CGSize(width: 0, height: 3)
        // Set the shadow opacity to 1.0, making it fully opaque.
        self.layer.shadowOpacity = 1.0
        // Set the shadow radius to 10.0, controlling the blur radius of the shadow.
        self.layer.shadowRadius = 10.0
        // Allow the shadow to extend beyond the bounds of the button.
        self.layer.masksToBounds = false
    }
}
