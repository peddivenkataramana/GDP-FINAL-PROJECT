import Foundation

// Struct to represent the main patient data, including details, patient lists, verification lists, medicine details, and report details.
struct PatientArray: Codable {
    let email: String?
    let name: String?
    let id: String?
    let userType: String?
    let patientList: [PatientList]?
    let verifyPatientList: [VerifyPatientList]?
    let medicineDetail: [MedicineDetail]?
    let reportDetail: [ReportDetail]?
}

// Struct to represent patient-specific information.
struct PatientList: Codable {
    let email: String?
    let name: String?
    let id: String?
    let patientRequest: String?
    let userType: String?
}

// Struct to represent the list of patients pending verification.
struct VerifyPatientList: Codable {
    let email: String?
    let name: String?
    let id: String?
    let patientRequest: String?
    let userType: String?
}

// Struct to represent details of prescribed medicines.
struct MedicineDetail: Codable {
    let startDate: String!
    let endDate: String!
    let medicineName: String!
    let medicineCount: String!
    let medicineType: String!
    let medicineTime: String!
    let medicineDay: [String]!
    let snoozeTime: String!
}

// Struct to represent details of medical reports.
struct ReportDetail: Codable {
    let fileName: String?
    let addReportName: String?
    let reportUrlPath: String?
}
