 
import UIKit

class ForgetPasswordManager {
    
    // A static method to send an email for password recovery.
    static func sendEmail(emailTo: String, body: String, completion: @escaping (Bool) -> Void) {
        
        // App-specific password for sending the email (replace with your actual app password).
        let myAppPassword = "ndwqkmxmasslmlld"
        
        // URL for the cloud function that sends the email.
        let url = URL(string: "https://us-central1-booking-app-629cf.cloudfunctions.net/sendEmail")!
        
        // Data to be sent in the request body.
        let data = [
            "subject": "Here Is your login Password For your SmartMedAssist App",
            "loginMail": "graduateproject37@gmail.com",
            "emailFrom": "graduateproject37@gmail.com",
            "emailTo": emailTo,
            "appPassword": myAppPassword,
            "body":  body
        ]
        
        // Convert data to JSON format.
        let jsonData = try! JSONSerialization.data(withJSONObject: data, options: [])
        
        // Create a POST request with the JSON data.
        var request = URLRequest(url: url)
        request.httpMethod = "POST"
        request.httpBody = jsonData
        request.setValue("application/json", forHTTPHeaderField: "Content-Type")

        // Create a session to perform the data task.
        let session = URLSession.shared
        let task = session.dataTask(with: request) { data, response, error in
            if let error = error {
                // Handle error in sending email.
                print("Error sending email: \(error.localizedDescription)")
                completion(false)
                return
            }

            guard let httpResponse = response as? HTTPURLResponse, (200..<300).contains(httpResponse.statusCode) else {
                // Handle invalid response.
                print("Error sending email: Invalid response")
                completion(false)
                return
            }

            // Email sent successfully.
            print("Email sent successfully")
            completion(true)
        }

        // Resume the task to initiate the request.
        task.resume()
    }
}
