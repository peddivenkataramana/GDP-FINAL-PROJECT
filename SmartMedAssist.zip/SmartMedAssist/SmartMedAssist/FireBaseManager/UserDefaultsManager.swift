 
import Foundation

class UserDefaultsManager {
    
    // Shared instance for singleton pattern.
    static let shared = UserDefaultsManager()
    
    // Clear all user defaults data.
    func clearUserDefaults() {
        let defaults = UserDefaults.standard
        let dictionary = defaults.dictionaryRepresentation()

        dictionary.keys.forEach { key in
            defaults.removeObject(forKey: key)
        }
    }
    
    // Check if the user is logged in based on the presence of an email in UserDefaults.
    func isLoggedIn() -> Bool {
        let email = getEmail()
        return !email.isEmpty
    }
     
    // Retrieve the stored email from UserDefaults.
    func getEmail() -> String {
        return UserDefaults.standard.string(forKey: "email") ?? ""
    }
    
    // Retrieve the stored name from UserDefaults.
    func getName() -> String {
        return UserDefaults.standard.string(forKey: "name") ?? ""
    }
    
    // Retrieve the stored department from UserDefaults.
    func getDepartment() -> String {
        return UserDefaults.standard.string(forKey: "department") ?? ""
    }
    
    // Retrieve the stored user type from UserDefaults.
    func getUserType() -> String {
        return UserDefaults.standard.string(forKey: "userType") ?? ""
    }
    
    // Save user data to UserDefaults.
    func saveData(name: String, email: String, userType: String) {
        UserDefaults.standard.setValue(name, forKey: "name")
        UserDefaults.standard.setValue(email, forKey: "email")
        UserDefaults.standard.setValue(userType, forKey: "userType")
    }
}

