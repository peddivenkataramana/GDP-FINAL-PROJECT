 
import UIKit
import FirebaseCore
import FirebaseFirestore
import FirebaseStorage
import Firebase
import FirebaseFirestoreSwift
 

class FireStoreManager {
    
  
    // Shared instance for singleton pattern.
    public static let shared = FireStoreManager()
    
    // Patient data model.
    var patient: PatientArray!
   
    // Firestore variables.
    var db: Firestore!
    var dbRef : CollectionReference!
    
    // Initialize Firestore and set up the collection reference.
    init() {
        let settings = FirestoreSettings()
        Firestore.firestore().settings = settings
        db = Firestore.firestore()
        dbRef = db.collection("Users")
    }
    
    // Update invite data for a specific document in Firestore.
    func updateInviteData(documentId: String, caretakerEmail: String, completion: @escaping (Bool)->()) {
        self.dbRef.whereField("inviteType", isEqualTo: "").getDocuments() { (querySnapshot, err) in
            if let err = err {
                print("Error: \(err.localizedDescription)")
                completion(false)
                return
            } else {
                let document = querySnapshot!.documents.first
                document?.reference.updateData([
                    "inviteType": caretakerEmail
                ])
                completion(true)
            }
        }
    }
    
    // Update patient list for a specific document in Firestore.
    func updatePatientList(documentId: String, email: String, completion: @escaping (Bool)->()) {
        self.dbRef.whereField("email", isEqualTo: email).getDocuments() { (querySnapshot, err) in
            if let err = err {
                print("Error: \(err.localizedDescription)")
                completion(false)
                return
            } else if querySnapshot!.documents.count != 1 {
                showAlerOnTop(message: "Error in addition")
            } else {
                let name = UserDefaultsManager.shared.getName()
                let email = UserDefaultsManager.shared.getEmail()
                let userType = UserDefaultsManager.shared.getUserType()

                let data = ["name":name , "email" : email , "userType" : userType, "id" : documentId, "patientRequest" : "pending"]

                let document = querySnapshot!.documents.first
                document?.reference.updateData([
                    "patientList": FieldValue.arrayUnion([data])
                ])
                completion(true)
            }
        }
    }
  
    // Accept patient request and update patient and verify patient lists in Firestore.
    func acceptPatientRequest(documentId: String, email: String, patientEmail: String, patientId: String, patientName: String, patientUserType: String, completion: @escaping (Bool)->()) {
        self.dbRef.whereField("email", isEqualTo: email).getDocuments() { (querySnapshot, err) in
            if let err = err {
                print("Error: \(err.localizedDescription)")
                completion(false)
                return
            } else if querySnapshot!.documents.count != 1 {
                showAlerOnTop(message: "Error in addition")
            } else {
                let name = UserDefaultsManager.shared.getName()
                let email = UserDefaultsManager.shared.getEmail()
                let userType = UserDefaultsManager.shared.getUserType()

                let data = ["name":patientName , "email" : patientEmail , "userType" : patientUserType, "id" : patientId, "patientRequest" : "pending"]

                let document = querySnapshot!.documents.first
                document?.reference.updateData([
                    "patientList": FieldValue.arrayRemove([data])
                ])
                
                let acceptData = ["name":patientName , "email" : patientEmail , "userType" : patientUserType, "id" : patientId, "patientRequest" : "Accepted"]

                document?.reference.updateData([
                    "verifyPatientList": FieldValue.arrayUnion([acceptData])
                ])
                completion(true)
            }
        }
    }
    
    // Update medicine detail for a specific document in Firestore.
    func updateMedicineDetail(documentId: String, email: String, completion: @escaping (Bool)->()) {
        self.dbRef.whereField("email", isEqualTo: email).getDocuments() { (querySnapshot, err) in
            if let err = err {
                print("Error: \(err.localizedDescription)")
                completion(false)
                return
            } else if querySnapshot!.documents.count != 1 {
                showAlerOnTop(message: "Error in addition")
            } else {
                let name = UserDefaultsManager.shared.getName()
                let email = UserDefaultsManager.shared.getEmail()
                let userType = UserDefaultsManager.shared.getUserType()

                let data = ["name":name , "email" : email , "userType" : userType, "id" : documentId, "patientRequest" : "pending"]

                let document = querySnapshot!.documents.first
                document?.reference.updateData([
                    "patientList": FieldValue.arrayUnion([data])
                ])
                completion(true)
            }
        }
    }
        
    // Sign up a new user and add data to Firestore.
    func signUp(name: String, email: String, password: String, userType: String, inviteType: String, patientList: [String]) {
        self.checkAlreadyExistAndSignup(name: name, email: email, password: password, userType: userType, inviteType: inviteType, patientList: patientList)
    }
    
    // Login user and perform necessary actions based on the retrieved data.
    func login(email: String, password: String, userType: String) {
        getQueryFromFirestore(field: "email", compareValue: email) { querySnapshot in
            print(querySnapshot.count)
            
            if(querySnapshot.count == 0) {
                showAlerOnTop(message: "Email id not found!!")
            } else {
                for document in querySnapshot.documents {
                    print("doclogin = \(document.documentID)")
                    UserDefaults.standard.setValue("\(document.documentID)", forKey: "documentId")

                    if let pwd = document.data()["password"] as? String {
                        if(pwd == password) {
                            let name = document.data()["name"] as? String ?? ""
                            let email = document.data()["email"] as? String ?? ""
                            let type = document.data()["userType"] as? String ?? ""
                            
                            if(userType == type ) {
                                UserDefaultsManager.shared.saveData(name: name, email: email, userType: userType)
                                SceneDelegate.shared?.loginCheckOrRestart()
                            } else {
                                showAlerOnTop(message: "You are not allowed to log in for this role")
                            }
                        } else {
                            showAlerOnTop(message: "Password doesn't match")
                        }
                    } else {
                        showAlerOnTop(message: "Something went wrong!!")
                    }
                }
            }
        }
    }
        
    // Check if the user already exists and sign up if not.
    func checkAlreadyExistAndSignup(name: String, email: String, password: String, userType: String, inviteType: String, patientList: [String]) {
        getQueryFromFirestore(field: "email", compareValue: email) { querySnapshot in
            print(querySnapshot.count)
            
            if(querySnapshot.count > 0) {
                showAlerOnTop(message: "This Email is Already Registered!!")
            } else {
                let data = ["name": name, "email": email, "password": password, "userType": userType, "inviteType": inviteType, "patientList": patientList] as [String: Any]
                
                self.addDataToFireStore(data: data) { _ in
                    showOkAlertAnyWhereWithCallBack(message: "Registration Success!!") {
                        DispatchQueue.main.async {
                            SceneDelegate.shared?.loginCheckOrRestart()
                        }
                    }
                }
            }
        }
    }
    
    // Add data to Firestore for a new user.
    func addDataToFireStore(data: [String: Any], completionHandler: @escaping (Any) -> Void) {
        dbRef.addDocument(data: data) { err in
            if let err = err {
                showAlerOnTop(message: "Error adding document: \(err)")
            } else {
                completionHandler("success")
            }
        }
    }
    
    // Retrieve data from Firestore based on a specific field and value.
    func getQueryFromFirestore(field: String, compareValue: String, completionHandler: @escaping (QuerySnapshot) -> Void) {
        dbRef.whereField(field, isEqualTo: compareValue).getDocuments { querySnapshot, err in
            if let err = err {
                showAlerOnTop(message: "Error getting documents: \(err)")
                return
            } else {
                if let querySnapshot = querySnapshot {
                    return completionHandler(querySnapshot)
                } else {
                    showAlerOnTop(message: "Something went wrong!!")
                }
            }
        }
    }
    
    // Add new medicine detail to Firestore for a specific user.
    func addNewMedicineDetail(email: String, startDate: String, endDate: String, medicineName: String, medicineCount: String, medicineType: String, medicineTime: String, medicineDay: [String], snoozeTime: String, completion: @escaping (Bool)->()) {
        self.dbRef.whereField("email", isEqualTo: email).getDocuments() { (querySnapshot, err) in
            if let err = err {
                print("err")
            } else if querySnapshot!.documents.count != 1 {
                showAlerOnTop(message: "Error in addition")
            } else {
                let data = ["startDate": startDate, "endDate": endDate, "medicineName": medicineName, "medicineCount": medicineCount, "medicineType": medicineType, "medicineTime": medicineTime, "medicineDay": medicineDay, "snoozeTime": snoozeTime] as [String: Any]
                
                let document = querySnapshot!.documents.first
                document?.reference.updateData([
                    "MedicineDetail": FieldValue.arrayUnion([data])
                ])
                completion(true)
            }
        }
    }

    
    // Update specific values in an array for a document in Firestore.
    func updateMedicineArrayValuesByKeys(documentID: String, arrayField: String, indexToUpdate: Int, newValue: Any, completion: @escaping (Bool)->()) {
        // Step 1: Retrieve the document
        dbRef.whereField("email", isEqualTo: documentID).getDocuments { querySnapshot, err in
            for document in querySnapshot!.documents {
                print("doclogin = \(document.documentID)")
                let patientDocId = document.documentID
                self.dbRef.document(patientDocId).getDocument { (document, error) in
                    guard let document = document, document.exists else {
                        print("Document does not exist")
                        return
                    }
                    
                    // Step 2: Modify the array element locally
                    if var array = document.data()?[arrayField] as? [Any], indexToUpdate >= 0 && indexToUpdate < array.count {
                        array[indexToUpdate] = newValue
                        
                        // Step 3: Update the Firestore document with the modified array
                        var updatedData = [String: Any]()
                        updatedData[arrayField] = array
                        self.dbRef.document(patientDocId).setData(updatedData, merge: true) { error in
                            if let error = error {
                                print("Error updating document: \(error.localizedDescription)")
                            } else {
                                completion(true)
                                print("Document updated successfully")
                            }
                        }
                    }
                }
            }
        }

    }
    // Add new report detail to Firestore for a specific user.
    func addNewReport(email: String, fileName: String, addReportName: String, reportUrlPath: String,completion: @escaping (Bool)->()) {
        self.dbRef.whereField("email", isEqualTo: email).getDocuments() { (querySnapshot, err) in
                if let err = err {
                    print("err")
                    // Some error occured
                } else if querySnapshot!.documents.count != 1 {
                    showAlerOnTop(message: "Error in addition")
                } else {
                    let data = ["fileName":fileName,"addReportName":addReportName,"reportUrlPath":reportUrlPath] as [String : Any]
                    
                    let document = querySnapshot!.documents.first
                    document?.reference.updateData([
                        "ReportDetail": FieldValue.arrayUnion([data])
                    ])
                    completion(true)
                }
            }
        
    }
}


extension FireStoreManager {
    // Retrieve all patient list data from Firestore for a specific user.
    func getAllPatientList(email:String,completionHandler:@escaping (QuerySnapshot) -> Void){
        
        
        let  query = dbRef.whereField("email", isEqualTo: email)
        
        query.getDocuments { (snapshot, err) in
                    
            if let _ = err {
                  return
            }else {
                
                
                if let querySnapshot = snapshot {
                    return completionHandler(querySnapshot)
                }else {
                    return
                }
               
            }
        }
          
    }
    // Retrieve all medicine list data from Firestore for a specific user.
    func getAllMedicineList(email:String,completionHandler:@escaping (QuerySnapshot) -> Void){
        
        
        let  query = dbRef.whereField("email", isEqualTo: email)
        
        query.getDocuments { (snapshot, err) in
                    
            if let _ = err {
                  return
            }else {
                
                
                if let querySnapshot = snapshot {
                    return completionHandler(querySnapshot)
                }else {
                    return
                }
               
            }
        }
          
    }
    // Retrieve all report list data from Firestore for a specific user.
    func getAllReportList(email:String,completionHandler:@escaping (QuerySnapshot) -> Void){
        
        
        let  query = dbRef.whereField("email", isEqualTo: email)
        
        query.getDocuments { (snapshot, err) in
                    
            if let _ = err {
                  return
            }else {
                
                
                if let querySnapshot = snapshot {
                    return completionHandler(querySnapshot)
                }else {
                    return
                }
               
            }
        }
          
    }
    // Retrieve password data from Firestore based on email.
    func getPassword(email:String,password:String,completion: @escaping (String)->()) {
        let  query = dbRef.whereField("email", isEqualTo: email)
        
        query.getDocuments { (querySnapshot, err) in
         
            if(querySnapshot?.count == 0) {
                showAlerOnTop(message: "Email id not found!!")
            }else {

                if querySnapshot != nil{
                    for document in querySnapshot!.documents {
                        print("doclogin = \(document.documentID)")
                        UserDefaults.standard.setValue("\(document.documentID)", forKey: "documentId")
                        if let pwd = document.data()["password"] as? String{
                            completion(pwd)
                        }else {
                            showAlerOnTop(message: "Something went wrong!!")
                        }
                    }
                }
            }
        }
   }
}
