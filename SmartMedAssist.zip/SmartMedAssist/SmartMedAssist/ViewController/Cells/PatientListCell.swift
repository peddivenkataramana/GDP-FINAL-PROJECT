
import UIKit

class PatientListCell: UITableViewCell {

    @IBOutlet weak var titleCell: UILabel?
    @IBOutlet weak var medicineCount: UILabel?
    @IBOutlet weak var medicineStartDate: UILabel?
    @IBOutlet weak var medicineEndDate: UILabel?
    @IBOutlet weak var medicineTime: UILabel?
    @IBOutlet weak var requestbtn: UIButton?

    @IBOutlet weak var medicineName: UITextField?
    @IBOutlet weak var dosePeriod: UITextField?
    @IBOutlet weak var tabletTime: UITextField?
    @IBOutlet weak var medicineType: UIButton?

}
