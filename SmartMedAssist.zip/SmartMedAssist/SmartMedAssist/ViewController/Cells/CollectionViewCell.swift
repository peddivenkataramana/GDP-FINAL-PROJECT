
import UIKit

class CollectionViewCell: UICollectionViewCell {
    @IBOutlet weak var titleCell: UILabel!
    @IBOutlet weak var backView: UIView!
    override var isSelected: Bool {
            didSet {
                backView.backgroundColor = isSelected ? .black : .white
                titleCell.textColor = isSelected ? .white : .black
            }
        }
}
