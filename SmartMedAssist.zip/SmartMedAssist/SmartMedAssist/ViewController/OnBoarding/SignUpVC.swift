

import UIKit

// MARK: - SignUpVC

class SignUpVC: UIViewController {

    // MARK: - Outlets

    @IBOutlet weak var name: UITextField!
    @IBOutlet weak var email: UITextField!
    @IBOutlet weak var password: UITextField!
    @IBOutlet weak var confirmPassword: UITextField!
    @IBOutlet weak var signUpLbl: UILabel!

    // MARK: - Properties

    var signUpTitle: String = ""

    // MARK: - View Lifecycle

    override func viewDidLoad() {
        super.viewDidLoad()

        // Set the title label based on the signUpTitle
        signUpLbl.text = "\(signUpTitle) Sign Up"
    }

    // MARK: - Button Actions

    @IBAction func onSignUp(_ sender: Any) {
        // Validate user input and sign up if validation succeeds
        if self.validate() {
            FireStoreManager.shared.signUp(
                name: name.text!,
                email: email.text!.lowercased(),
                password: password.text!,
                userType: signUpTitle,
                inviteType: "",
                patientList: []
            )
        }
    }

    @IBAction func onBack(_ sender: Any) {
        // Navigate back to the previous view controller in the navigation stack
        self.navigationController?.popViewController(animated: true)
    }

    // MARK: - Validation

    func validate() -> Bool {

        // Check if name is empty
        if self.name.text!.isEmpty {
            showAlerOnTop(message: "Please enter name.")
            return false
        }

        // Check if email is empty
        if self.email.text!.isEmpty {
            showAlerOnTop(message: "Please enter email.")
            return false
        }

        // Check if email is in correct format
        if !email.text!.emailIsCorrect() {
            showAlerOnTop(message: "Please enter a valid email id")
            return false
        }

        // Check if password is empty
        if self.password.text!.isEmpty {
            showAlerOnTop(message: "Please enter password.")
            return false
        }

        // Check if confirm password is empty
        if self.confirmPassword.text!.isEmpty {
            showAlerOnTop(message: "Please enter confirm password.")
            return false
        }

        // Check if password and confirm password match
        if self.password.text! != self.confirmPassword.text! {
            showAlerOnTop(message: "Password doesn't match")
            return false
        }

        // Check if password length is within the specified range
        if self.password.text!.count < 5 || self.password.text!.count > 10 {
            showAlerOnTop(message: "Password length should be between 5 to 10 characters")
            return false
        }

        return true
    }
}
