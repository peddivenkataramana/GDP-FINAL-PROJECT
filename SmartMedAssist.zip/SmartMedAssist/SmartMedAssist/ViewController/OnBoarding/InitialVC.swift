

import UIKit

// MARK: - InitialVC

class InitialVC: UIViewController {
    
    // MARK: - View Lifecycle
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Additional setup or configuration can be performed here upon the view's loading.
    }

    // MARK: - Button Actions
    
    @IBAction func onSignin(_ sender: Any) {
        // Instantiate SignInVC from the storyboard and push it onto the navigation stack
        let vc = self.storyboard?.instantiateViewController(withIdentifier: "SignInVC") as! SignInVC
        self.navigationController?.pushViewController(vc, animated: true)
    }
    
    @IBAction func onSignUp(_ sender: Any) {
        // Instantiate SignUpOptionVC from the storyboard and push it onto the navigation stack
        let vc = self.storyboard?.instantiateViewController(withIdentifier: "SignUpOptionVC") as! SignUpOptionVC
        self.navigationController?.pushViewController(vc, animated: true)
    }
}
