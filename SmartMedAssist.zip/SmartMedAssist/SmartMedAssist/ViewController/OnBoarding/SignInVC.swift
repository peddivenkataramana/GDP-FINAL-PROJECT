

import UIKit

// MARK: - UserType Enumeration

enum UserType: String {
    case patient = "Patient"
    case pharmacist = "Pharmacist"
}

// MARK: - SignInVC

class SignInVC: UIViewController {
    
    // MARK: - Outlets
    
    @IBOutlet weak var email: UITextField!
    @IBOutlet weak var password: UITextField!
    @IBOutlet weak var segment: UISegmentedControl!
    
    // MARK: - Properties
    
    var userType = UserType.patient.rawValue
    
    // MARK: - View Lifecycle
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Additional setup or configuration can be performed here upon the view's loading.
    }

    // MARK: - Button Actions
    
    @IBAction func onSignin(_ sender: Any) {
        // Validate user input and initiate the login process
        if email.text!.isEmpty {
            showAlerOnTop(message: "Please enter your email id.")
            return
        }

        if password.text!.isEmpty {
            showAlerOnTop(message: "Please enter your password.")
            return
        } else {
            FireStoreManager.shared.login(email: email.text!.lowercased(), password: password.text!, userType: userType)
        }
    }

    @IBAction func onBack(_ sender: Any) {
        // Navigate back to the previous view controller in the navigation stack
        self.navigationController?.popViewController(animated: true)
    }
    
    @IBAction func segmentDidChange(_ sender: UISegmentedControl) {
        // Update the userType based on the selected segment in the UISegmentedControl
        switch sender.selectedSegmentIndex {
        case 0:
            userType = UserType.patient.rawValue
        case 1:
            userType = UserType.pharmacist.rawValue
        default:
            break
        }
    }
    
    @IBAction func onForgotPassword(_ sender: Any) {
        // Navigate to the ForgotPassword view controller
        let vc = self.storyboard?.instantiateViewController(withIdentifier: "ForgotPassword") as! ForgotPassword
        self.navigationController?.pushViewController(vc, animated: true)
    }
}
