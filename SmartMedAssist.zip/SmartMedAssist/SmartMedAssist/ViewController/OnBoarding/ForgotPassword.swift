//
//  ForgotPassword.swift
//  SmartMedAssist
//

import UIKit

class ForgotPassword: UIViewController {
    // MARK: - Outlets
       @IBOutlet weak var email: UITextField!

       // MARK: - View Lifecycle
       override func viewDidLoad() {
           super.viewDidLoad()
           // Additional setup code, if any
       }

       // MARK: - Actions

       /// Handles the "Back" button press to navigate back in the view hierarchy.
       @IBAction func onBack(_ sender: Any) {
           self.navigationController?.popViewController(animated: true)
       }

       /// Handles the "Send" button press for initiating the password reset process.
       @IBAction func onSend(_ sender: Any) {
        
        if(email.text!.isEmpty) {
            showAlerOnTop(message: "Please enter your email id.")
            return
        }
        
        if !email.text!.emailIsCorrect() {
            showAlerOnTop(message: "Please enter valid email id")
            return
        }
        
        else{
            FireStoreManager.shared.getPassword(email: self.email.text ?? "", password: "") { password in
                self.forgotPassword(password: password)
            }
        }
    }
    
    func forgotPassword(password: String) {
        let body = "<H1> Your password is \(password) </H1>"
        
        // Show a loading spinner
        let loadingIndicator = UIActivityIndicatorView()
        loadingIndicator.style = .medium
        loadingIndicator.center =  self.view.center
        self.view.addSubview(loadingIndicator)
        loadingIndicator.startAnimating()
        
        // Call the sendEmail function and handle its response
        ForgetPasswordManager.sendEmail(emailTo: self.email.text ?? "", body: body) { success in
            DispatchQueue.main.async {
                loadingIndicator.stopAnimating()
                if success {
                    showAlerOnTop(message: "Please check your email box for password")
                } else {
                    showAlerOnTop(message: "Error sending email")
                }
            }
        }
    }
}
