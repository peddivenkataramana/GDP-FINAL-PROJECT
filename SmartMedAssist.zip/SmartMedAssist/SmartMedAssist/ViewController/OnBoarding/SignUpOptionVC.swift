
import UIKit

// MARK: - SignUpOptionVC

class SignUpOptionVC: UIViewController {
    
    // MARK: - View Lifecycle
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Additional setup or configuration can be performed here upon the view's loading.
    }

    // MARK: - Button Actions
    
    @IBAction func onPatient(_ sender: Any) {
        // Navigate to the SignUpVC with the title set to "Patient"
        let vc = self.storyboard?.instantiateViewController(withIdentifier: "SignUpVC") as! SignUpVC
        vc.signUpTitle = "Patient"
        self.navigationController?.pushViewController(vc, animated: true)
    }
    
    @IBAction func onCaretaker(_ sender: Any) {
        // Navigate to the SignUpVC with the title set to "Pharmacist"
        let vc = self.storyboard?.instantiateViewController(withIdentifier: "SignUpVC") as! SignUpVC
        vc.signUpTitle = "Pharmacist"
        self.navigationController?.pushViewController(vc, animated: true)
    }
    
    @IBAction func onBack(_ sender: Any) {
        // Navigate back to the previous view controller in the navigation stack
        self.navigationController?.popViewController(animated: true)
    }
}
