import UIKit
import MobileCoreServices
import FirebaseStorage
import FirebaseAuth

class AddReportVC: UIViewController, UIImagePickerControllerDelegate, UINavigationControllerDelegate {
    
    @IBOutlet weak var fileName: UITextField!
    @IBOutlet weak var addFileName: UILabel!
    
    var email = ""
    let imagePicker = UIImagePickerController()
    
    var docImageBool = false
    var selectedImage = UIImage()
    var docUrls = [URL]()
    var activityIndicator: UIActivityIndicatorView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        imagePicker.delegate = self
        imagePicker.sourceType = .photoLibrary
        
        activityIndicator = UIActivityIndicatorView(style: .large)
        activityIndicator.hidesWhenStopped = true
        activityIndicator.center = view.center
        view.addSubview(activityIndicator)
    }
    
    @IBAction func onBack(_ sender: Any) {
        self.navigationController?.popViewController(animated: true)
    }
    
    @IBAction func uploadFileAction(_ sender: Any) {
        let actionSheet = UIAlertController(title: "Choose Option", message: nil, preferredStyle: .actionSheet)
        
        let chooseImageAction = UIAlertAction(title: "Choose Image", style: .default) { [weak self] _ in
            self?.openImagePicker()
        }
        
        let chooseDocumentAction = UIAlertAction(title: "Choose Document", style: .default) { [weak self] _ in
            self?.openDocumentPicker()
        }
        
        let cancelAction = UIAlertAction(title: "Cancel", style: .cancel, handler: nil)
        
        actionSheet.addAction(chooseImageAction)
        actionSheet.addAction(chooseDocumentAction)
        actionSheet.addAction(cancelAction)
        
        if let popoverController = actionSheet.popoverPresentationController {
            popoverController.sourceView = sender as! UIView
            popoverController.sourceRect = (sender as AnyObject).bounds
        }
        
        present(actionSheet, animated: true, completion: nil)
    }
    
    func openImagePicker() {
        docImageBool = false
        present(imagePicker, animated: true, completion: nil)
    }
    
    func openDocumentPicker() {
        docImageBool = true
        let documentPicker = UIDocumentPickerViewController(documentTypes: ["com.microsoft.word.doc", kUTTypePDF as String], in: .import)
        documentPicker.delegate = self
        documentPicker.allowsMultipleSelection = true
        present(documentPicker, animated: true, completion: nil)
    }
    
    func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [UIImagePickerController.InfoKey : Any]) {
        if let selectedImage = info[UIImagePickerController.InfoKey.originalImage] as? UIImage {
            if let imageURL = info[UIImagePickerController.InfoKey.imageURL] as? URL {
                let imageName = imageURL.lastPathComponent
                print("Image Name: \(imageName)")
                self.selectedImage = selectedImage
                self.addFileName.text = imageName
            }
        }
        
        picker.dismiss(animated: true, completion: nil)
    }
    
    @IBAction func btnAddReport(_ sender: UIButton) {
        self.fileName.resignFirstResponder()
        if validate() {
            self.activityIndicator.startAnimating()
            self.view.isUserInteractionEnabled = false
            
            if docImageBool {
                self.uploadFileInToFirebase(urls: self.docUrls)
            }
            
            self.uploadImageToFirebase(image: selectedImage, imageName: self.addFileName.text ?? "")
        }
    }
    
    func validate() -> Bool {
        if self.fileName.text!.isEmpty {
            showAlerOnTop(message: "Please enter file name")
            return false
        }
        
        if self.addFileName.text!.isEmpty {
            showAlerOnTop(message: "Please add report.")
            return false
        }
        return true
    }
}

extension AddReportVC: UIDocumentPickerDelegate {
    func documentPicker(_ controller: UIDocumentPickerViewController, didPickDocumentsAt urls: [URL]) {
        if let selectedPDFURL = urls.first {
            addFileName.text = selectedPDFURL.lastPathComponent
            self.docUrls = urls
        }
    }
}

extension AddReportVC {
    func uploadImageToFirebase(image: UIImage, imageName: String) {
        let storage = Storage.storage()
        let imageRef = storage.reference().child("Documents/\(email)/\(imageName)")
        
        if let imageData = image.jpegData(compressionQuality: 0.7) {
            imageRef.putData(imageData, metadata: nil) { (metadata, error) in
                if let error = error {
                    print("Error uploading image: \(error.localizedDescription)")
                } else {
                    imageRef.downloadURL { (url, error) in
                        if let downloadURL = url {
                            let stringValue = downloadURL.absoluteString
                            FireStoreManager.shared.addNewReport(email: self.email, fileName: self.fileName.text ?? "", addReportName: self.addFileName.text ?? "", reportUrlPath: stringValue) { success in
                                if success {
                                    DispatchQueue.main.async {
                                        self.activityIndicator.stopAnimating()
                                        self.view.isUserInteractionEnabled = true
                                        showAlerOnTop(message: "Report added successfully")
                                        self.navigationController?.popViewController(animated: true)
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
    
    func uploadFileInToFirebase(urls: [URL]) {
        for url in urls {
            let fileType = url.pathExtension.lowercased()
            let storage = Storage.storage()
            let storageRef = storage.reference().child("Documents/\(email)/\(fileType)")
            
            storageRef.putFile(from: url, metadata: nil) { (metadata, error) in
                if let error = error {
                    print("Error uploading file: \(error.localizedDescription)")
                } else {
                    storageRef.downloadURL { (url, error) in
                        if let downloadURL = url {
                            let stringValue = downloadURL.absoluteString
                            FireStoreManager.shared.addNewReport(email: self.email, fileName: self.fileName.text ?? "", addReportName: self.addFileName.text ?? "", reportUrlPath: stringValue) { success in
                                if success {
                                    DispatchQueue.main.async {
                                        self.activityIndicator.stopAnimating()
                                        self.view.isUserInteractionEnabled = true
                                        showAlerOnTop(message: "Report added successfully")
                                        self.navigationController?.popViewController(animated: true)
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
