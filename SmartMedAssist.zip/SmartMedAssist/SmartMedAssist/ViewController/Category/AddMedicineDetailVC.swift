
import UIKit
typealias Handler = () -> Void

class AddMedicineDetailVC: UIViewController {
    @IBOutlet weak var medicineStartDate: UITextField!
    @IBOutlet weak var medicineEndDate: UITextField!
    @IBOutlet weak var medicineTime: UITextField!
    @IBOutlet weak var name: UITextField!
    @IBOutlet weak var count: UITextField!
    @IBOutlet weak var snoozeTime: UITextField!

    @IBOutlet weak var collectionView: UICollectionView!
    @IBOutlet weak var tabletCount: UITextField!
    var callback : ((Int)->())?
    let datePicker = UIDatePicker()
    let timePicker = UIDatePicker()
    var medicineType = "Before Food"
    var selectedDays = [Int]()
    var weekdaysToCount: Set<Calendar.DayOfWeek> = []
    var email = ""
    var medicineDay = [String]()
    var dayList : [Any] = []
    var counter = 1 {
          didSet {
              tabletCount.text = "\(counter) min"
          }
        }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // Enable multiple selection in the collectionView
        collectionView.allowsMultipleSelection = true

        // Set up input views for date and time pickers
        medicineStartDate.inputView = datePicker
        medicineEndDate.inputView = datePicker
        medicineStartDate.inputView = datePicker
        medicineTime.inputView = timePicker

        // Set up date pickers and time pickers
        showDatePicker()
        showEndDatePicker()
        showOpeningTimePicker()

        // Set up collectionView delegate and data source
        collectionView.delegate = self
        collectionView.dataSource = self

        // Initialize array of dates and scroll to the second item
        arrayOfDates()
        collectionView.scrollToItem(at: IndexPath(item: 1, section: 0), at: .left, animated: true)
        
        // Additional configuration for input views
        medicineStartDate.inputView = datePicker
        medicineTime.inputView = timePicker
    }

    // Increase button action
    @IBAction func btnIncreaseAction(_ sender: UIButton) {
        counter += 1
        callback?(counter)
    }

    // Decrease button action
    @IBAction func btnDecreaseAction(_ sender: UIButton) {
        if counter > 1 { counter -= 1 }
        callback?(counter)
    }

    // Segment control action
    @IBAction func segmentDidChange(_ sender: UISegmentedControl) {
        switch sender.selectedSegmentIndex {
        case 0:
            medicineType = "Before Food"
        case 1:
            medicineType = "After Food"
        default:
            break
        }
    }

    // Back button action
    @IBAction func onBack(_ sender: Any) {
        self.navigationController?.popViewController(animated: true)
    }

    // Show start date picker button action
    @IBAction func showStratDatepicker(_ sender: UIButton) {
        showDatePicker()
    }

    // Show end date picker button action
    @IBAction func showEndDatepicker(_ sender: UIButton) {
        showEndDatePicker()
    }

    // Add medicine detail button action
    @IBAction func btnAddMedicineDetail(_ sender: UIButton) {
        // Validate input fields
        if validate() {
            // Add medicine detail to Firestore
            FireStoreManager.shared.addNewMedicineDetail(email: email, startDate: medicineStartDate.text ?? "", endDate: medicineEndDate.text ?? "", medicineName: name.text ?? "", medicineCount: count.text ?? "", medicineType: medicineType, medicineTime: medicineTime.text ?? "", medicineDay: medicineDay, snoozeTime: snoozeTime.text ?? "1") { success in
                if success {
                    // Show success alert
                    showAlerOnTop(message: "Medicine added successfully")
                    
                    // Pop to root view controller
                    self.navigationController?.popToRootViewController(animated: true)

                    // Example usage:
                    let dateFormatter = DateFormatter()
                    dateFormatter.dateFormat = "MM-dd-yyyy"
                    let startDate = dateFormatter.date(from: self.medicineStartDate.text ?? "")!
                    let endDate = dateFormatter.date(from: self.medicineEndDate.text ?? "")!

                    // Calculate weekdays count
                    let counthj = self.countWeekdaysBetween(startDate: startDate, endDate: endDate, weekdays: self.weekdaysToCount)

                    let dateFormatter1 = DateFormatter()
                    dateFormatter1.dateFormat = "HH:mm"
                    var currentDate = Date()
                    currentDate = Calendar.current.date(byAdding: .minute, value: self.counter, to: currentDate)!
                    let formattedDate = dateFormatter1.string(from: currentDate)
                    print("Formatted Date: \(formattedDate)")

                    let selectedTimes: [String] = [self.medicineTime.text ?? "", formattedDate]

                    // Schedule local notifications
                    self.scheduleNotificationsForSelectedDaysAndTimes(selectedDays: self.selectedDays, selectedTimes: selectedTimes)
                }
            }
        }
    }

    // Function to schedule local notifications
    func scheduleNotificationsForSelectedDaysAndTimes(selectedDays: [Int], selectedTimes: [String]) {
        let content = UNMutableNotificationContent()
        content.title = "Medicine Time"
        content.body = "You should take your \(name.text ?? "") medicine"
        content.sound = UNNotificationSound.default

        let calendar = Calendar.current

        for day in selectedDays {
            for time in selectedTimes {
                var dateComponents = DateComponents()
                let timeComponents = time.components(separatedBy: ":")
                
                if let hour = Int(timeComponents[0]), let minute = Int(timeComponents[1]) {
                    dateComponents.hour = hour
                    dateComponents.minute = minute
                    dateComponents.weekday = day
                    
                    let trigger = UNCalendarNotificationTrigger(dateMatching: dateComponents, repeats: true)
                    
                    // Create a unique identifier for each notification
                    let identifier = "notification_\(day)_\(hour)_\(minute)"
                    
                    let request = UNNotificationRequest(identifier: identifier, content: content, trigger: trigger)
                    
                    UNUserNotificationCenter.current().add(request) { (error) in
                        if let error = error {
                            print("Error scheduling notification: \(error.localizedDescription)")
                        } else {
                            print("Notification scheduled successfully for \(Calendar.DayOfWeek(rawValue: day)!), \(hour):\(minute)")
                        }
                    }
                }
            }
        }
    }

    func validate() ->Bool {
        
        if(self.medicineStartDate.text!.isEmpty) {
             showAlerOnTop(message: "Please enter medicine start date.")
            return false
        }
        
        if(self.medicineEndDate.text!.isEmpty) {
            showAlerOnTop(message: "Please enter medicine end date.")
           return false
       }
        
        if(self.name.text!.isEmpty) {
             showAlerOnTop(message: "Please enter medicine name.")
            return false
        }
        
        if(self.count.text!.isEmpty) {
             showAlerOnTop(message: "Please enter medicine count.")
            return false
        }
        
        if(self.medicineTime.text!.isEmpty) {
             showAlerOnTop(message: "Please enter medicine time.")
            return false
        }
        
        if(self.snoozeTime.text!.isEmpty) {
             showAlerOnTop(message: "Please enter snooze time.")
            return false
        }
        return true
    }
    
    func arrayOfDates() {

            let numberOfDays: Int = 7
            let formatter: DateFormatter = DateFormatter()
            formatter.dateFormat = "EE"
            let startDate = Date()
            let calendar = Calendar.current
            var offset = DateComponents()
            dayList = [formatter.string(from: startDate)]

            for i in 1..<numberOfDays {
                offset.day = i
                let nextDay: Date? = calendar.date(byAdding: offset, to: startDate)
                let nextDayString = formatter.string(from: nextDay!)
                dayList.append(nextDayString)
            }
        print("day =",dayList)
        
        }
}

extension AddMedicineDetailVC {
    func showDatePicker() {
        //Formate Date
        datePicker.datePickerMode = .date
        if #available(iOS 13.4, *) {
            datePicker.preferredDatePickerStyle = .wheels
        } else {
            // Fallback on earlier versions
        }
        //ToolBar
        let toolbar = UIToolbar();
        toolbar.sizeToFit()
        
        //done button & cancel button
        let doneButton = UIBarButtonItem(title: "Done", style: .plain, target: self, action: #selector(self.doneHolydatePicker))
        doneButton.tintColor = .black
        let spaceButton = UIBarButtonItem(barButtonSystemItem: .flexibleSpace, target: nil, action: nil)
        let cancelButton = UIBarButtonItem(title: "Cancel", style: .plain, target: self, action: #selector(self.cancelDatePicker))
        cancelButton.tintColor = .black
        toolbar.setItems([cancelButton,spaceButton,doneButton], animated: false)
        
        // add toolbar to textField
        medicineStartDate.inputAccessoryView = toolbar
        // add datepicker to textField
        medicineStartDate.inputView = datePicker
        
    }
    
    @objc func doneHolydatePicker() {
        //For date formate
        let formatter = DateFormatter()
        formatter.dateFormat = "MM-dd-yyyy"
        medicineStartDate.text = formatter.string(from: datePicker.date)
        //dismiss date picker dialog
        self.view.endEditing(true)
    }
    
    @objc func cancelDatePicker() {
        self.view.endEditing(true)
    }
    
    func showEndDatePicker() {
        //Formate Date
        datePicker.datePickerMode = .date
        if #available(iOS 13.4, *) {
            datePicker.preferredDatePickerStyle = .wheels
        } else {
            // Fallback on earlier versions
        }
        //ToolBar
        let toolbar = UIToolbar();
        toolbar.sizeToFit()
        
        //done button & cancel button
        let doneButton = UIBarButtonItem(title: "Done", style: .plain, target: self, action: #selector(self.doneEnddatePicker))
        doneButton.tintColor = .black
        let spaceButton = UIBarButtonItem(barButtonSystemItem: .flexibleSpace, target: nil, action: nil)
        let cancelButton = UIBarButtonItem(title: "Cancel", style: .plain, target: self, action: #selector(self.cancelEndDatePicker))
        cancelButton.tintColor = .black
        toolbar.setItems([cancelButton,spaceButton,doneButton], animated: false)
        
        // add toolbar to textField
        medicineEndDate.inputAccessoryView = toolbar
        // add datepicker to textField
        medicineEndDate.inputView = datePicker
        
    }
    
    @objc func doneEnddatePicker() {
        //For date formate
        let formatter = DateFormatter()
        formatter.dateFormat = "MM-dd-yyyy"
        medicineEndDate.text = formatter.string(from: datePicker.date)
        //dismiss date picker dialog
        self.view.endEditing(true)
    }
    
    @objc func cancelEndDatePicker() {
        self.view.endEditing(true)
    }
    
    func showOpeningTimePicker() {
        //Formate Date
        timePicker.datePickerMode = .time
        if #available(iOS 13.4, *) {
            timePicker.preferredDatePickerStyle = .wheels
        } else {
            // Fallback on earlier versions
        }
        //ToolBar
        let toolbar = UIToolbar();
        toolbar.sizeToFit()
        
        //done button & cancel button
        let doneButton = UIBarButtonItem(title: "Done", style: .plain, target: self, action: #selector(self.doneOpingTimePicker))
        doneButton.tintColor = .black
        let spaceButton = UIBarButtonItem(barButtonSystemItem: .flexibleSpace, target: nil, action: nil)
        let cancelButton = UIBarButtonItem(title: "Cancel", style: .plain, target: self, action: #selector(self.cancelDatePicker))
        cancelButton.tintColor = .black
        toolbar.setItems([cancelButton,spaceButton,doneButton], animated: false)
        
        // add toolbar to textField
        medicineTime.inputAccessoryView = toolbar
        // add datepicker to textField
        medicineTime.inputView = timePicker
       
    }
    
    @objc func doneOpingTimePicker() {
        //For date formate
        let formatter = DateFormatter()
        formatter.dateFormat = "HH:mm"
        medicineTime.text = formatter.string(from: timePicker.date)
       // txtOpeingTime.textFieldDidChange(txtOpeingTime)
        //dismiss date picker dialog
        self.view.endEditing(true)
    }

  }

extension AddMedicineDetailVC: UICollectionViewDelegate, UICollectionViewDataSource {
    func numberOfSections(in collectionView: UICollectionView) -> Int {
        return 1
    }
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return dayList.count
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: String(describing: CollectionViewCell.self), for: indexPath) as! CollectionViewCell
        cell.titleCell.text = dayList[indexPath.row] as! String
        return cell
    }
    
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        let day = dayList[indexPath.row] as! String
        medicineDay.append(day)
        if day == "Sun"{
            selectedDays.append(1)
            weekdaysToCount.insert(.sunday)
        }
        if day == "Mon"{
            selectedDays.append(2)
            weekdaysToCount.insert(.monday)
        }
        if day == "Tue"{
            selectedDays.append(3)
            weekdaysToCount.insert(.tuesday)

        }
        if day == "Wed"{
            selectedDays.append(4)
            weekdaysToCount.insert(.wednesday)

        }
        if day == "Thu"{
            selectedDays.append(5)
            weekdaysToCount.insert(.thursday)

        }
        if day == "Fri"{
            selectedDays.append(6)
            weekdaysToCount.insert(.friday)

        }
        if day == "Sat"{
            selectedDays.append(7)
            weekdaysToCount.insert(.saturday)

        }
        
        print("weekdays == ",weekdaysToCount)
       }
    
    func collectionView(_ collectionView: UICollectionView, didDeselectItemAt indexPath: IndexPath) {
        let day = dayList[indexPath.row] as! String
        medicineDay.remove(element: day)
        if day == "Sun"{
            selectedDays.remove(element: 1)
            weekdaysToCount.remove(.sunday)
        }
        if day == "Mon"{
            selectedDays.remove(element: 2)
            weekdaysToCount.remove(.monday)
        }
        if day == "Tue"{
            selectedDays.remove(element: 3)
            weekdaysToCount.remove(.tuesday)
        }
        if day == "Wed"{
            selectedDays.remove(element: 4)
            weekdaysToCount.remove(.wednesday)
        }
        if day == "Thu"{
            selectedDays.remove(element: 5)
            weekdaysToCount.remove(.thursday)
        }
        if day == "Fri"{
            selectedDays.remove(element: 6)
            weekdaysToCount.remove(.friday)
        }
        if day == "Sat"{
            selectedDays.remove(element: 7)
            weekdaysToCount.remove(.saturday)
        }
       }
    
    @IBAction func onLeftClick(_ sender: Any) {
        let collectionBounds = self.collectionView.bounds
        let contentOffset = CGFloat(floor(self.collectionView.contentOffset.x - collectionBounds.size.width))
        self.moveCollectionToFrame(contentOffset: contentOffset)
    }
    
    @IBAction func onRightClick(_ sender: Any) {

           let collectionBounds = self.collectionView.bounds
           let contentOffset = CGFloat(floor(self.collectionView.contentOffset.x + collectionBounds.size.width))
           self.moveCollectionToFrame(contentOffset: contentOffset)

       }

       func moveCollectionToFrame(contentOffset : CGFloat) {

           let frame: CGRect = CGRect(x : contentOffset ,y : self.collectionView.contentOffset.y ,width : self.collectionView.frame.width,height : self.collectionView.frame.height)
           self.collectionView.scrollRectToVisible(frame, animated: true)
       }
}

extension AddMedicineDetailVC{
    
    func daysBetween(start: Date, end: Date) -> Int {
        let calendar = Calendar.current
        let date1 = calendar.startOfDay(for: start)
        let date2 = calendar.startOfDay(for: end)
        
        let components = calendar.dateComponents([.day], from: date1, to: date2)
        
        return components.day ?? 0
    }
    
    func countWeekdaysBetween(startDate: Date, endDate: Date, weekdays: Set<Calendar.DayOfWeek>) -> Int {
        let calendar = Calendar.current
        var currentDate = startDate
        var weekdayCount = 0
        
        while currentDate <= endDate {
            let dayOfWeek = calendar.component(.weekday, from: currentDate)
            if weekdays.contains(Calendar.DayOfWeek(rawValue: dayOfWeek)!) {
                weekdayCount += 1
            }
            currentDate = calendar.date(byAdding: .day, value: 1, to: currentDate)!
        }
        
        return weekdayCount
    }
}

    // Define an extension to represent weekdays.
    extension Calendar {
        enum DayOfWeek: Int {
            case sunday = 1, monday, tuesday, wednesday, thursday, friday, saturday
        }
    }

extension Array where Element: Equatable{
    mutating func remove (element: Element) {
        if let i = self.index(of: element) {
            self.remove(at: i)
        }
    }
}
