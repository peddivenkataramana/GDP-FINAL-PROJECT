import UIKit

class ViewReminderVC: UIViewController {
    @IBOutlet weak var tableView: UITableView!

    // Variables to store user email and medicine list
    var email = ""
    var medicineList: [MedicineDetail] = [] {
        didSet {
            tableView.reloadData()
        }
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
    }
    
    // Fetch medicine list from Firestore when the view is about to appear
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        self.getMedicineList()
    }
    
    // Function to retrieve medicine list from Firestore
    func getMedicineList() {
        FireStoreManager.shared.getAllMedicineList(email: self.email) { querySnapshot in
            var itemsArray = [self.medicineList]
            print(querySnapshot.documents)
            for (_, document) in querySnapshot.documents.enumerated() {
                do {
                    let item = try document.data(as: PatientArray.self)
                    itemsArray.append(item.medicineDetail ?? [])
                    print(itemsArray)
                } catch let error {
                    print(error)
                }
            }
            if itemsArray.count > 1 {
                self.medicineList = itemsArray[1]
            }
            self.tableView.reloadData()
        }
    }

    // Action when the "Back" button is tapped
    @IBAction func onBack(_ sender: Any) {
        self.navigationController?.popViewController(animated: true)
    }
    
    // Function to snooze a scheduled local notification
    func snoozeScheduledNotification(notification: UILocalNotification) -> Void {
        // Snooze for 10 mins
        let localNotification = UILocalNotification()
        localNotification.fireDate = notification.fireDate?.addingTimeInterval(60 * 10)
        localNotification.repeatInterval = NSCalendar.Unit(rawValue: 0) // 0 = No Repeat
        localNotification.alertBody = notification.alertBody
        localNotification.soundName = notification.soundName
        localNotification.userInfo = notification.userInfo
        localNotification.category = notification.category
        UIApplication.shared.scheduleLocalNotification(localNotification)
    }
}

// Extension to adopt UITableViewDelegate and UITableViewDataSource protocols
extension ViewReminderVC: UITableViewDelegate, UITableViewDataSource {
    
    // Number of sections in the table view
    func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
    
    // Number of rows in the table view
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return self.medicineList.count
    }

    // Create and return a cell for a given row and section
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier:  String(describing: PatientListCell.self), for: indexPath) as! PatientListCell
        let data = self.medicineList[indexPath.row]
        cell.medicineName?.text = data.medicineName
        cell.dosePeriod?.text = "\(data.startDate ?? "") to \(data.endDate ?? "")"
        cell.tabletTime?.text = data.medicineTime
        cell.medicineType?.setTitle(data.medicineType, for: .normal)
        return cell
    }
    
    // Height for each row in the table view
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 265
    }
}
