import UIKit
import PDFKit
import WebKit

class ReportDetailVC: UIViewController, UIDocumentInteractionControllerDelegate {
    
    // Outlet to connect with the main view in the storyboard
    @IBOutlet weak var mainView: UIView!
    
    // Instance of UIDocumentInteractionController for document interaction
    var documentController: UIDocumentInteractionController?
    
    // Variables to store filename and file path
    var filename = ""
    var filePath = ""
    
    // PDFView for displaying PDF content
    let pdfView = PDFView()
    
    // WebView for displaying other document types
    @IBOutlet var webView: WKWebView!
    
    // Activity indicator for loading state
    var activityIndicator: UIActivityIndicatorView!

    override func viewDidLoad() {
        super.viewDidLoad()
        
        // Load PDF or other document types based on the file path
        if let url = URL(string: filePath) {
            let request = URLRequest(url: url)
            webView.load(request)
        }
        
        // Set up the activity indicator
        activityIndicator = UIActivityIndicatorView(style: .medium)
        activityIndicator.hidesWhenStopped = true
        activityIndicator.center = view.center
        view.addSubview(activityIndicator)
    }
    
    // Function to open a document using UIDocumentInteractionController
    func openDocument(atPath filePath: String) {
        let docURL = URL(fileURLWithPath: filePath)
        documentController = UIDocumentInteractionController(url: docURL)
        documentController?.delegate = self
        documentController?.presentPreview(animated: true)
    }
    
    // Implement the UIDocumentInteractionControllerDelegate method
    func documentInteractionControllerViewControllerForPreview(_ controller: UIDocumentInteractionController) -> UIViewController {
        return self
    }

    // Action when the "Back" button is tapped
    @IBAction func onBack(_ sender: Any) {
        self.navigationController?.popViewController(animated: true)
    }
    
    // Function to display a PDF file using PDFView
    func displayPDF() {
        // Replace "yourFileName" with the actual name of your PDF file
        if let pdfURL = getDocumentDirectoryURL(for: filename) {
            if let pdfDocument = PDFDocument(url: pdfURL) {
                pdfView.document = pdfDocument
            }
        }
    }
    
    // Function to get the document directory URL for a given file name
    func getDocumentDirectoryURL(for fileName: String) -> URL? {
        // Get the document directory URL
        if let documentDirectory = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask).first {
            // Append the file name to the document directory URL
            return documentDirectory.appendingPathComponent(fileName)
        }
        return nil
    }
}
