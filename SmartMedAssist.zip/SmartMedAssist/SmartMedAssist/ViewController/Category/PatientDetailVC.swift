import UIKit

class PatientDetailVC: UIViewController {

    // Variable to store the patient's email
    var patientEmail = ""
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }
    
    // Action when the "Back" button is tapped
    @IBAction func onBack(_ sender: Any) {
        self.navigationController?.popViewController(animated: true)
    }
    
    // Action when the "View Reminder" button is tapped
    @IBAction func onViewReminder(_ sender: Any) {
        // Instantiate ViewReminderVC and set the patient's email
        let vc = self.storyboard?.instantiateViewController(withIdentifier: "ViewReminderVC") as! ViewReminderVC
        vc.email = patientEmail
        self.navigationController?.pushViewController(vc, animated: true)
    }
    
    // Action when the "Medicine History" button is tapped
    @IBAction func onMedicineHistory(_ sender: Any) {
        // Instantiate MedicineHistoryVC and set the patient's email
        let vc = self.storyboard?.instantiateViewController(withIdentifier: "MedicineHistoryVC") as! MedicineHistoryVC
        vc.patientEmailId = patientEmail
        self.navigationController?.pushViewController(vc, animated: true)
    }
}
