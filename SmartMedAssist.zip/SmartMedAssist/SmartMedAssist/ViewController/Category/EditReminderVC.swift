import UIKit

class EditReminderVC: UIViewController {
    
    // Outlet to connect with the table view in the storyboard
    @IBOutlet weak var tableView: UITableView!
    
    // Array to store the list of medicines
    var medicineList: [MedicineDetail] = [] {
        didSet {
            tableView.reloadData()
        }
    }
    
    // Variable to store the user's email
    var email = ""
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // Set the delegate and data source for the table view
        self.tableView.delegate = self
        self.tableView.dataSource = self
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        // Fetch the list of medicines when the view appears
        self.getMedicineList()
    }
    
    // Function to fetch the list of medicines from Firestore
    func getMedicineList() {
        FireStoreManager.shared.getAllMedicineList(email: email) { querySnapshot in
            var itemsArray = [self.medicineList]
            print(querySnapshot.documents)
            for (_, document) in querySnapshot.documents.enumerated() {
                do {
                    let item = try document.data(as: PatientArray.self)
                    itemsArray.append(item.medicineDetail ?? [])
                    print(itemsArray)
                } catch let error {
                    print(error)
                }
            }
            self.medicineList = itemsArray[1]
            self.tableView.reloadData()
        }
    }
    
    // Action when the "Back" button is tapped
    @IBAction func onBack(_ sender: Any) {
        self.navigationController?.popViewController(animated: true)
    }
}

extension EditReminderVC: UITableViewDelegate, UITableViewDataSource {
    
    // Number of sections in the table view
    func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
    
    // Number of rows in the table view
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return self.medicineList.count
    }

    // Configure and return a cell for a specific row
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier:  String(describing: PatientListCell.self), for: indexPath) as! PatientListCell
        let data = self.medicineList[indexPath.row]
        cell.titleCell?.text = data.medicineName
        return cell
    }
    
    // Height for each row in the table view
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 60
    }
    
    // Action when a row is selected
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let data = self.medicineList[indexPath.row]
        // Instantiate and push the TabletDetailVC
        let vc = self.storyboard?.instantiateViewController(withIdentifier:  "TabletDetailVC" ) as! TabletDetailVC
        vc.tabletValue = data
        vc.email = email
        vc.indexValue = indexPath.row
        self.navigationController?.pushViewController(vc, animated: true)
    }
}
