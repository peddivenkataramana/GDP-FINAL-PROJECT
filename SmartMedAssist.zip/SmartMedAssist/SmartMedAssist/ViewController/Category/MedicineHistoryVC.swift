import UIKit

class MedicineHistoryVC: UIViewController {
    
    @IBOutlet weak var tableView: UITableView!
    
    // Variables to store patient email and medicine details
    var patientEmailId = ""
    var medicineDetail: [MedicineDetail] = [] {
        didSet {
            tableView.reloadData()
        }
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Set the delegate and data source for the table view
        self.tableView.delegate = self
        self.tableView.dataSource = self
        
        // Check user type and fetch medicine list accordingly
        let userType = UserDefaultsManager.shared.getUserType()
        if userType == UserType.patient.rawValue {
            self.getMedicineList(email: UserDefaultsManager.shared.getEmail())
        } else {
            if patientEmailId != "" {
                self.getMedicineList(email: patientEmailId)
            }
        }
    }
    
    // Action when the "Back" button is tapped
    @IBAction func onBack(_ sender: Any) {
        self.navigationController?.popViewController(animated: true)
    }
    
    // Function to get the medicine list from Firestore
    func getMedicineList(email: String) {
        FireStoreManager.shared.getAllMedicineList(email: email) { querySnapshot in
            var itemsArray = [self.medicineDetail]
            print(querySnapshot.documents)
            for (_, document) in querySnapshot.documents.enumerated() {
                do {
                    let item = try document.data(as: PatientArray.self)
                    itemsArray.append(item.medicineDetail ?? [])
                    print(itemsArray)
                } catch let error {
                    print(error)
                }
            }
            self.medicineDetail = itemsArray[1]
            self.tableView.reloadData()
        }
    }
}

// Extension to adopt UITableViewDelegate and UITableViewDataSource protocols
extension MedicineHistoryVC: UITableViewDelegate, UITableViewDataSource {
    
    // Number of sections in the table view
    func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
    
    // Number of rows in the table view
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return self.medicineDetail.count
    }

    // Create and return a cell for a given row and section
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier:  String(describing: PatientListCell.self), for: indexPath) as! PatientListCell
        let data = self.medicineDetail[indexPath.row]
        cell.titleCell?.text = data.medicineName
        cell.medicineCount?.text = "Count : \(data.medicineCount ?? "")"
        cell.medicineStartDate?.text = "Date : \(data.startDate ?? "")"
        cell.medicineTime?.text = "Time : \(data.medicineTime ?? "")"
        return cell
    }
    
    // Height for each row in the table view
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 105
    }
}
