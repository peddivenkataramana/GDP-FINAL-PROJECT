
import UIKit

class TabletDetailVC : UIViewController {
    @IBOutlet weak var tabletName: UITextField!
    @IBOutlet weak var startdate: UITextField!
    @IBOutlet weak var endDate: UITextField!
    @IBOutlet weak var time: UITextField!
    @IBOutlet weak var segment: UISegmentedControl!
    @IBOutlet weak var tabletCount: UITextField!
    var medicineType = ""
    var tabletValue : MedicineDetail!
    let datePicker = UIDatePicker()
    let timePicker = UIDatePicker()
    var indexValue = Int()

    var email = ""
    var callback : ((Int)->())?

    var counter = 1 {
          didSet {
              tabletCount.text = "\(counter)"
          }
        }
    
    override func viewDidLoad() {
        super.viewDidLoad()

        self.tabletName.text = tabletValue.medicineName
        self.startdate.text = tabletValue.startDate
        self.endDate.text = tabletValue.endDate
        self.time.text = tabletValue.medicineTime
        self.tabletCount.text = tabletValue.medicineCount
        counter = Int(tabletValue.medicineCount) ?? 1
        self.medicineType = tabletValue.medicineType ?? "Before Food"
        
        if self.medicineType == "Before Food"{
            segment.selectedSegmentIndex = 0
        } else {
            segment.selectedSegmentIndex = 1
        }
        
        self.startdate.inputView =  datePicker
        self.endDate.inputView =  datePicker

        self.showDatePicker()
        self.showEndDatePicker()
        showOpeningTimePicker()
        
        startdate.inputView = self.datePicker
        endDate.inputView = self.datePicker
        time.inputView = self.timePicker
    }
    
    @IBAction func segmentDidChange(_ sender: UISegmentedControl) {
        switch sender.selectedSegmentIndex {
        case 0:
            medicineType = "Before Food"
        case 1:
            medicineType = "After Food"
        default:
            break
        }
    }
    
    @IBAction func btnIncreaseAction(_ sender: UIButton) {
        counter += 1
        callback?(counter)
    }

    @IBAction func btnDecreaseAction(_ sender: UIButton) {
        if counter > 1 { counter -= 1 }
        callback?(counter)
    }

    @IBAction func onBack(_ sender: Any) {
        self.navigationController?.popViewController(animated: true)
    }
    
    @IBAction func btnEditMedicineDetail(_ sender: UIButton) {
        FireStoreManager.shared.updateMedicineArrayValuesByKeys(documentID: email, arrayField: "MedicineDetail", indexToUpdate: indexValue, newValue: ["startDate": startdate.text ?? "", "endDate": endDate.text ?? "", "medicineName": tabletName.text ?? "", "medicineCount": tabletCount.text ?? "", "medicineType": medicineType, "medicineTime": time.text ?? "", "medicineDay": tabletValue.medicineDay ?? "", "snoozeTime": tabletValue.snoozeTime ?? ""] as [String : Any], completion: { success in
                            if success{
                                
                                let dateFormatter = DateFormatter()
                                dateFormatter.dateFormat = "MM-dd-yyyy"
                                let startDate = dateFormatter.date(from: self.startdate.text ?? "")!
                                let endDate = dateFormatter.date(from: self.endDate.text ?? "")!

                                
                                let dateFormatter1 = DateFormatter()
                                dateFormatter1.dateFormat = "HH:mm"
                                
                                var currentDate = Date()
                                
                                currentDate = Calendar.current.date(byAdding: .minute, value: 1, to: currentDate)!
                                let formattedDate = dateFormatter1.string(from: currentDate)
                                
                                print("Formatted Date: \(formattedDate)")
                                
                                let selectedTimes: [String] = [self.tabletValue.medicineTime ?? "",formattedDate]
                                
                                let selectedDays = self.mapDaysToIntegerArray(days: self.tabletValue.medicineDay)

                                self.scheduleNotificationsForSelectedDaysAndTimes(selectedDays: selectedDays, selectedTimes: selectedTimes)
                                
                                showAlerOnTop(message: "Medicine edited successfully")
                                self.navigationController?.popViewController(animated: true)
                            }
                        })
    }
    
    func mapDaysToIntegerArray(days: [String]) -> [Int] {
        let dayMapping: [String: Int] = [
            "Sun": 1,
            "Mon": 2,
            "Tue": 3,
            "Wed": 4,
            "Thu": 5,
            "Fri": 6,
            "Sat": 7
        ]

        var integerArray: [Int] = []

        for day in days {
            if let intValue = dayMapping[day] {
                integerArray.append(intValue)
            }
        }

        return integerArray
    }
    
    func scheduleNotificationsForSelectedDaysAndTimes(selectedDays: [Int], selectedTimes: [String]) {
        let content = UNMutableNotificationContent()
        content.title = "Medicine Time"
        content.body = "You should take your \(tabletName.text ?? "") medicine"
        content.sound = UNNotificationSound.default

        let calendar = Calendar.current
        
        for day in selectedDays {
            for time in selectedTimes {
                var dateComponents = DateComponents()
                let timeComponents = time.components(separatedBy: ":")
                
                if let hour = Int(timeComponents[0]), let minute = Int(timeComponents[1]) {
                    dateComponents.hour = hour
                    dateComponents.minute = minute
                    dateComponents.weekday = day
                    
                    let trigger = UNCalendarNotificationTrigger(dateMatching: dateComponents, repeats: true)
                    
                    // Create a unique identifier for each notification
                    let identifier = "notification_\(day)_\(hour)_\(minute)"
                    
                    let request = UNNotificationRequest(identifier: identifier, content: content, trigger: trigger)
                    
                    UNUserNotificationCenter.current().add(request) { (error) in
                        if let error = error {
                            print("Error scheduling notification: \(error.localizedDescription)")
                        } else {
                            print("Notification scheduled successfully for \(Calendar.DayOfWeek(rawValue: day)!), \(hour):\(minute)")
                        }
                    }
                }
            }
        }
    }

    
    func validate() ->Bool {
        if(self.tabletName.text!.isEmpty) {
             showAlerOnTop(message: "Please enter medicine name.")
            return false
        }
        
        if(self.startdate.text!.isEmpty) {
             showAlerOnTop(message: "Please enter medicine start date.")
            return false
        }
        
        if(self.endDate.text!.isEmpty) {
            showAlerOnTop(message: "Please enter medicine end date.")
           return false
       }
                
        if(self.tabletCount.text!.isEmpty) {
             showAlerOnTop(message: "Please enter medicine count.")
            return false
        }
        
        if(self.time.text!.isEmpty) {
             showAlerOnTop(message: "Please enter medicine time.")
            return false
        }
        
        return true
    }
}

extension TabletDetailVC {
    func showDatePicker() {
        //Formate Date
        datePicker.datePickerMode = .date
        if #available(iOS 13.4, *) {
            datePicker.preferredDatePickerStyle = .wheels
        } else {
            // Fallback on earlier versions
        }
        //ToolBar
        let toolbar = UIToolbar();
        toolbar.sizeToFit()
        
        //done button & cancel button
        let doneButton = UIBarButtonItem(title: "Done", style: .plain, target: self, action: #selector(self.doneHolydatePicker))
        doneButton.tintColor = .black
        let spaceButton = UIBarButtonItem(barButtonSystemItem: .flexibleSpace, target: nil, action: nil)
        let cancelButton = UIBarButtonItem(title: "Cancel", style: .plain, target: self, action: #selector(self.cancelDatePicker))
        cancelButton.tintColor = .black
        toolbar.setItems([cancelButton,spaceButton,doneButton], animated: false)
        
        // add toolbar to textField
        startdate.inputAccessoryView = toolbar
        // add datepicker to textField
        startdate.inputView = datePicker
        
    }
    
    @objc func doneHolydatePicker() {
        //For date formate
        let formatter = DateFormatter()
        formatter.dateFormat = "MM-dd-yyyy"
        startdate.text = formatter.string(from: datePicker.date)
        //dismiss date picker dialog
        self.view.endEditing(true)
    }
    
    @objc func cancelDatePicker() {
        self.view.endEditing(true)
    }
    
    func showEndDatePicker() {
        //Formate Date
        datePicker.datePickerMode = .date
        if #available(iOS 13.4, *) {
            datePicker.preferredDatePickerStyle = .wheels
        } else {
            // Fallback on earlier versions
        }
        //ToolBar
        let toolbar = UIToolbar();
        toolbar.sizeToFit()
        
        //done button & cancel button
        let doneButton = UIBarButtonItem(title: "Done", style: .plain, target: self, action: #selector(self.doneEnddatePicker))
        doneButton.tintColor = .black
        let spaceButton = UIBarButtonItem(barButtonSystemItem: .flexibleSpace, target: nil, action: nil)
        let cancelButton = UIBarButtonItem(title: "Cancel", style: .plain, target: self, action: #selector(self.cancelEndDatePicker))
        cancelButton.tintColor = .black
        toolbar.setItems([cancelButton,spaceButton,doneButton], animated: false)
        
        // add toolbar to textField
        endDate.inputAccessoryView = toolbar
        // add datepicker to textField
        endDate.inputView = datePicker
        
    }
    
    @objc func doneEnddatePicker() {
        //For date formate
        let formatter = DateFormatter()
        formatter.dateFormat = "MM-dd-yyyy"
        endDate.text = formatter.string(from: datePicker.date)
        //dismiss date picker dialog
        self.view.endEditing(true)
    }
    
    @objc func cancelEndDatePicker() {
        self.view.endEditing(true)
    }
    
    func showOpeningTimePicker() {
        //Formate Date
        timePicker.datePickerMode = .time
        if #available(iOS 13.4, *) {
            timePicker.preferredDatePickerStyle = .wheels
        } else {
            // Fallback on earlier versions
        }
        //ToolBar
        let toolbar = UIToolbar();
        toolbar.sizeToFit()
        
        //done button & cancel button
        let doneButton = UIBarButtonItem(title: "Done", style: .plain, target: self, action: #selector(self.doneOpingTimePicker))
        doneButton.tintColor = .black
        let spaceButton = UIBarButtonItem(barButtonSystemItem: .flexibleSpace, target: nil, action: nil)
        let cancelButton = UIBarButtonItem(title: "Cancel", style: .plain, target: self, action: #selector(self.cancelDatePicker))
        cancelButton.tintColor = .black
        toolbar.setItems([cancelButton,spaceButton,doneButton], animated: false)
        
        // add toolbar to textField
        time.inputAccessoryView = toolbar
        // add datepicker to textField
        time.inputView = timePicker
       
    }
    
    @objc func doneOpingTimePicker() {
        //For date formate
        let formatter = DateFormatter()
        formatter.dateFormat = "HH:mm"
        time.text = formatter.string(from: timePicker.date)
       // txtOpeingTime.textFieldDidChange(txtOpeingTime)
        //dismiss date picker dialog
        self.view.endEditing(true)
    }

  }

