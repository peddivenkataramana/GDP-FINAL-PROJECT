import UIKit

class CategoryVC: UIViewController {

    // Outlets
    @IBOutlet weak var tableView: UITableView!
    @IBOutlet weak var backBtn: UIButton!
    
    // Properties
    var patientEmail = ""
    var categoryTitle = [String]()
    
    // Patient list
    var patientlist: [VerifyPatientList] = [] {
        didSet {
            tableView.reloadData()
        }
    }

    override func viewDidLoad() {
        super.viewDidLoad()

        // Set up the table view delegate and data source
        self.tableView.delegate = self
        self.tableView.dataSource = self

        // Determine the user type and set up the category titles accordingly
        let userType = UserDefaultsManager.shared.getUserType()
        if userType == UserType.pharmacist.rawValue {
            backBtn.isHidden = false
            categoryTitle = ["Add Medicine Detail", "Edit Medicine", "View Reminder", "Medicine History", "Health Report"]
        } else {
            backBtn.isHidden = true
            categoryTitle = ["View Reminder", "Medicine History", "Health Report"]
            self.getPatientList()
        }
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        
        // If the user is a pharmacist, get the patient list
        let userType = UserDefaultsManager.shared.getUserType()
        if userType == UserType.pharmacist.rawValue {
            self.getPatientList()
        }
    }
    
    // Function to fetch the patient list
    func getPatientList(){
        let email = UserDefaultsManager.shared.getEmail()
        FireStoreManager.shared.getAllPatientList(email: email) { querySnapshot in
            
            var itemsArray = [self.patientlist]
            print(querySnapshot.documents)
            
            // Check if there are any documents in the query snapshot
            if querySnapshot.count != nil {
                for (_,document) in querySnapshot.documents.enumerated() {
                    do {
                        let item = try document.data(as: PatientArray.self)
                        itemsArray.append(item.verifyPatientList ?? [])
                        
                        print(itemsArray)
                        
                    } catch let error {
                        print(error)
                    }
                }
                if itemsArray.count > 1 {
                    self.patientlist = itemsArray[1]
                }
                self.tableView.reloadData()
            }
        }
    }
    
    // Action when the "Back" button is tapped
    @IBAction func onBack(_ sender: Any) {
        self.navigationController?.popViewController(animated: true)
    }
}

// MARK: - Table View Delegate and Data Source
extension CategoryVC: UITableViewDelegate, UITableViewDataSource {
    
    func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return self.categoryTitle.count
    }

    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let userType = UserDefaultsManager.shared.getUserType()
        let cell = tableView.dequeueReusableCell(withIdentifier: String(describing: PatientListCell.self), for: indexPath) as! PatientListCell
        cell.titleCell?.text = categoryTitle[indexPath.row]
        return cell
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 60
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let userType = UserDefaultsManager.shared.getUserType()
        let title = self.categoryTitle[indexPath.row]

        // Navigate to the respective view controller based on the selected category title
        if userType == UserType.patient.rawValue {
            if title == "Health Report" {
                let vc = self.storyboard?.instantiateViewController(withIdentifier: "HealthReportVC") as! HealthReportVC
                vc.email = UserDefaultsManager.shared.getEmail()
                self.navigationController?.pushViewController(vc, animated: true)
            }
            if title == "View Reminder" {
                let vc = self.storyboard?.instantiateViewController(withIdentifier: "ViewReminderVC") as! ViewReminderVC
                vc.email = UserDefaultsManager.shared.getEmail()
                self.navigationController?.pushViewController(vc, animated: true)
            }
            if title == "Medicine History" {
                let vc = self.storyboard?.instantiateViewController(withIdentifier: "MedicineHistoryVC") as! MedicineHistoryVC
                vc.patientEmailId = UserDefaultsManager.shared.getEmail()
                self.navigationController?.pushViewController(vc, animated: true)
            }
        } else {
            // Navigate to the respective view controller based on the selected category title for pharmacist
            if title == "Add Medicine Detail" {
                let vc = self.storyboard?.instantiateViewController(withIdentifier: "AddMedicineDetailVC") as! AddMedicineDetailVC
                vc.email = patientEmail
                self.navigationController?.pushViewController(vc, animated: true)
            }
            if title == "Edit Medicine" {
                let vc = self.storyboard?.instantiateViewController(withIdentifier: "EditReminderVC") as! EditReminderVC
                vc.email = patientEmail
                self.navigationController?.pushViewController(vc, animated: true)
            }
            if title == "Health Report" {
                let vc = self.storyboard?.instantiateViewController(withIdentifier: "HealthReportVC") as! HealthReportVC
                vc.email = patientEmail
                self.navigationController?.pushViewController(vc, animated: true)
            }
            if title == "View Reminder" {
                let vc = self.storyboard?.instantiateViewController(withIdentifier: "ViewReminderVC") as! ViewReminderVC
                vc.email = patientEmail
                self.navigationController?.pushViewController(vc, animated: true)
            }
            if title == "Medicine History" {
                let vc = self.storyboard?.instantiateViewController(withIdentifier: "MedicineHistoryVC") as! MedicineHistoryVC
                vc.patientEmailId = patientEmail
                self.navigationController?.pushViewController(vc, animated: true)
            }
        }
    }
}
