import UIKit

class HealthReportVC: UIViewController {
    
    // Variable to store the email
    var email = ""

    override func viewDidLoad() {
        super.viewDidLoad()

        // Additional setup after loading the view, if needed.
    }
    
    // Action when the "Back" button is tapped
    @IBAction func onBack(_ sender: Any) {
        self.navigationController?.popViewController(animated: true)
    }

    // Action when the "Add Report" button is tapped
    @IBAction func onAddReport(_ sender: Any) {
        // Instantiate and push the AddReportVC
        let vc = self.storyboard?.instantiateViewController(withIdentifier:  "AddReportVC" ) as! AddReportVC
        vc.email = email
        self.navigationController?.pushViewController(vc, animated: true)
    }
    
    // Action when the "List Report" button is tapped
    @IBAction func onListReport(_ sender: Any) {
        // Instantiate and push the ListReportVC
        let vc = self.storyboard?.instantiateViewController(withIdentifier:  "ListReportVC" ) as! ListReportVC
        vc.email = email
        self.navigationController?.pushViewController(vc, animated: true)
    }
}
