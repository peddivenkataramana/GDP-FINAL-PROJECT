import UIKit

class ListReportVC: UIViewController {
    
    // Outlet to connect with the table view in the storyboard
    @IBOutlet weak var tableView: UITableView!
    
    // Array to store the list of reports
    var reportList: [ReportDetail] = [] {
        didSet {
            tableView.reloadData()
        }
    }
    
    // Variable to store the user's email
    var email = ""

    override func viewDidLoad() {
        super.viewDidLoad()
        
        // Set the delegate and data source for the table view
        self.tableView.delegate = self
        self.tableView.dataSource = self
        
        // Fetch the list of reports when the view is loaded
        self.getReportList()
    }
    
    // Action when the "Back" button is tapped
    @IBAction func onBack(_ sender: Any) {
        self.navigationController?.popViewController(animated: true)
    }
    
    // Function to fetch the list of reports from Firestore
    func getReportList() {
        FireStoreManager.shared.getAllReportList(email: email) { querySnapshot in
            var itemsArray = [self.reportList]
            print(querySnapshot.documents)
            for (_, document) in querySnapshot.documents.enumerated() {
                do {
                    let item = try document.data(as: PatientArray.self)
                    itemsArray.append(item.reportDetail ?? [])
                    print(itemsArray)
                } catch let error {
                    print(error)
                }
            }
            self.reportList = itemsArray[1]
            self.tableView.reloadData()
        }
    }
}

extension ListReportVC: UITableViewDelegate, UITableViewDataSource {
    
    // Number of sections in the table view
    func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
    
    // Number of rows in the table view
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return self.reportList.count
    }

    // Configure and return a cell for a specific row
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier:  String(describing: PatientListCell.self), for: indexPath) as! PatientListCell
        let data = self.reportList[indexPath.row]
        cell.titleCell?.text = data.fileName
        return cell
    }
    
    // Height for each row in the table view
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 60
    }
    
    // Action when a row is selected
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let data = self.reportList[indexPath.row]
        // Instantiate and push the ReportDetailVC
        let vc = self.storyboard?.instantiateViewController(withIdentifier:  "ReportDetailVC" ) as! ReportDetailVC
        vc.filename = data.addReportName ?? ""
        vc.filePath = data.reportUrlPath ?? ""
        self.navigationController?.pushViewController(vc, animated: true)
    }
}
