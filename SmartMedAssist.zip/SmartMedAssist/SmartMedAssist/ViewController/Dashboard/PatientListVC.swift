
import UIKit

// MARK: - PatientListVC

class PatientListVC: UIViewController {
    
    // MARK: - Outlets
    
    @IBOutlet weak var patientView: UIView!
    @IBOutlet weak var caretakerView: UIView!
    @IBOutlet weak var titleLabel: UILabel!
    
    // MARK: - View Lifecycle
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // Determine the user type from UserDefaults
        let userType = UserDefaultsManager.shared.getUserType()
        
        // Show or hide views based on user type
        if userType == UserType.patient.rawValue {
            self.patientView.isHidden = false
            self.caretakerView.isHidden = true
            titleLabel?.text = "Invite Pharmacist"
        } else {
            self.patientView.isHidden = true
            self.caretakerView.isHidden = false
            titleLabel?.text = "Patient List"
        }
    }
}

