
import UIKit

class AllPatientListVC: UIViewController {
    @IBOutlet weak var tableView: UITableView!
    @IBOutlet weak var segment: UISegmentedControl!
    var patientVerify = true
    
    var patientlist: [PatientList] = [] {
        didSet {
            tableView.reloadData()
        }
    }
    
    var verifyPatientlist: [VerifyPatientList] = [] {
        didSet {
            tableView.reloadData()
        }
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.tableView.delegate = self
        self.tableView.dataSource = self
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        let userType = UserDefaultsManager.shared.getUserType()
        
        if userType == UserType.patient.rawValue {
            self.getVerifyPatientList()
        }
        
    }
    
    @IBAction func segmentDidChange(_ sender: UISegmentedControl) {
        switch sender.selectedSegmentIndex {
        case 0:
            self.getPatientList()
            self.patientVerify = true
        case 1:
            self.getVerifyPatientList()
            self.patientVerify = false
        default:
            break
        }
    
    }
    // Fetch patient list
    func getPatientList(){
        let email = UserDefaultsManager.shared.getEmail()
        FireStoreManager.shared.getAllPatientList(email: email) { querySnapshot in
            
            var itemsArray = [self.patientlist]
            print(querySnapshot.documents)
            for (_,document) in querySnapshot.documents.enumerated() {
                do {
                    let item = try document.data(as: PatientArray.self)
                    itemsArray.append(item.patientList ?? [])
                    
                    print(itemsArray)
                 
                }catch let error {
                    print(error)
                }
            }
            self.patientlist = itemsArray[1]
            self.tableView.reloadData()

        }
    }
    // Fetch verified patient list
    func getVerifyPatientList(){
        let email = UserDefaultsManager.shared.getEmail()
        FireStoreManager.shared.getAllPatientList(email: email) { querySnapshot in
            
            var itemsArray = [self.verifyPatientlist]
            print(querySnapshot.documents)
            for (_,document) in querySnapshot.documents.enumerated() {
                do {
                    let item = try document.data(as: PatientArray.self)
                    itemsArray.append(item.verifyPatientList ?? [])
                    
                    print(itemsArray)
                 
                }catch let error {
                    print(error)
                }
            }
            if itemsArray.count > 0{
                self.verifyPatientlist = itemsArray[1]
            }
            
            self.tableView.reloadData()

        }
    }
    // Show alert for accepting the patient request
    func showAlert(patientName: String, tag: Int){
        let alert = UIAlertController(title: "", message: "Yor received an invite for pharmacist of \(patientName)", preferredStyle: UIAlertController.Style.alert)
        
        alert.addAction(UIAlertAction(title: "Accept", style: .default, handler: { (action:UIAlertAction) in
            let email = UserDefaultsManager.shared.getEmail()
            let documentId = UserDefaults.standard.string(forKey: "documentId") ?? ""

            FireStoreManager.shared.acceptPatientRequest(documentId: documentId, email: email, patientEmail: self.patientlist[tag].email ?? "", patientId: self.patientlist[tag].id ?? "", patientName: self.patientlist[tag].name ?? "", patientUserType: self.patientlist[tag].userType ?? "") { success in
                self.patientVerify = true
                self.getPatientList()
                showAlerOnTop(message: "Invitation accepted successfully")
            }
        }))
        
        alert.addAction(UIAlertAction(title: "Cancel", style: UIAlertAction.Style.cancel, handler: nil))
        
        self.present(alert, animated: true, completion: nil)
    }
}
// MARK: - UITableViewDelegate, UITableViewDataSource
extension AllPatientListVC: UITableViewDelegate, UITableViewDataSource {
    
    func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        if patientVerify{
            return self.verifyPatientlist.count
        } else {
            return self.patientlist.count
        }
        return self.patientlist.count
    }

    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        // Configure cell for verified patients
        if patientVerify{
            let cell = tableView.dequeueReusableCell(withIdentifier:  String(describing: PatientListCell.self), for: indexPath) as! PatientListCell
            let data = self.verifyPatientlist[indexPath.row]
            cell.titleCell?.text = data.name
            cell.requestbtn?.isHidden = true
            return cell
        } else {// Configure cell for pending patients
            let cell = tableView.dequeueReusableCell(withIdentifier:  String(describing: PatientListCell.self), for: indexPath) as! PatientListCell
            let data = self.patientlist[indexPath.row]
            cell.titleCell?.text = data.name
            cell.requestbtn?.isHidden = false
            cell.requestbtn?.tag = indexPath.row
            cell.requestbtn?.addTarget(self, action: #selector(acceptRequest(_:)), for: .touchUpInside)
            return cell
        }
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 60
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        // Handle selection for verified patients
        let data = self.verifyPatientlist[indexPath.row]
        let vc = self.storyboard?.instantiateViewController(withIdentifier:  "CategoryVC" ) as! CategoryVC
        vc.patientEmail = data.email ?? ""
        self.navigationController?.pushViewController(vc, animated: true)

    }
    
    @objc func acceptRequest(_ sender: UIButton){
        // Handle the accept request action

        self.showAlert(patientName: self.patientlist[sender.tag].name ?? "", tag: sender.tag)
    }
}
