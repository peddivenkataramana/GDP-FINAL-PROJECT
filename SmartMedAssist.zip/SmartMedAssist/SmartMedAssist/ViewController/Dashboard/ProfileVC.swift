
import UIKit

class ProfileVC: UIViewController {
    
    // MARK: - Outlets
    
    @IBOutlet weak var name: UILabel!
    @IBOutlet weak var email: UILabel!

    // MARK: - View Lifecycle
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Set the name and email labels with user data from UserDefaults
        self.name.text = UserDefaultsManager.shared.getName()
        self.email.text = UserDefaultsManager.shared.getEmail()
    }
    
    // MARK: - Actions
    
    @IBAction func onSignOut(_ sender: Any) {
        // Clear user defaults and remove documentId from standard UserDefaults
        UserDefaultsManager.shared.clearUserDefaults()
        UserDefaults.standard.removeObject(forKey: "documentId")

        // Perform a login check or restart to navigate to the appropriate screen
        SceneDelegate.shared!.loginCheckOrRestart()
    }
}
