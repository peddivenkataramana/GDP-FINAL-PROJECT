
import UIKit
class CaretakerInviteVC: UIViewController {
    @IBOutlet weak var email: UITextField!

    override func viewDidLoad() {
        super.viewDidLoad()
    }
    
    // Function to validate the entered email
    func validate() -> Bool {
        if self.email.text!.isEmpty {
            showAlerOnTop(message: "Please enter email.")
            return false
        }
        
        if !email.text!.emailIsCorrect() {
            showAlerOnTop(message: "Please enter a valid email id")
            return false
        }
        
        return true
    }
    
    // Action when the "Invite Caretaker" button is tapped
    @IBAction func onInviteCaretaker(_ sender: Any) {
        if self.validate() {
            let documentId = UserDefaults.standard.string(forKey: "documentId") ?? ""
            
            // Update invitation data in Firestore
            FireStoreManager.shared.updateInviteData(documentId: documentId, caretakerEmail: email.text ?? "") { success in
                if success {
                    // Update patient list in Firestore
                    FireStoreManager.shared.updatePatientList(documentId: documentId, email: self.email.text ?? "") { success in
                        showOkAlertAnyWhereWithCallBack(message: "Invitation sent successfully") {
                            self.email.text = ""
                            self.email.resignFirstResponder()
                        }
                    }
                } else {
                    showAlerOnTop(message: "Error")
                }
            }
        }
    }
}
