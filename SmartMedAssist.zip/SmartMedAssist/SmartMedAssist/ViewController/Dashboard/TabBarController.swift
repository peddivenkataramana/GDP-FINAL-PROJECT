//
//  TabBarController.swift
//  Online Diagnosis
//
//

import UIKit

// MARK: - MyTabBarController

class MyTabBarController: UITabBarController {

    // MARK: - View Lifecycle

    override func viewDidLoad() {
        super.viewDidLoad()

        // Replace 1 with the index of the tab item you want to hide
        let indexToHide = 1
        let indexToChange = 0

        // Get the user type from UserDefaults
        let userType = UserDefaultsManager.shared.getUserType()

        // Check if the user is a pharmacist
        if userType == UserType.pharmacist.rawValue {
            // Hide the tab item at the specified index
            if indexToHide < viewControllers?.count ?? 0 {
                // Create a new array without the view controller you want to hide
                var updatedViewControllers = viewControllers ?? []
                updatedViewControllers.remove(at: indexToHide)

                // Set the updated view controllers array
                setViewControllers(updatedViewControllers, animated: false)
            }
        }

        // Check if the user is a patient
        if userType == UserType.patient.rawValue {
            // Change the title of the first tab item
            self.tabBar.items?[indexToChange].title = "Pharmacist Invite"
        }
    }
}
